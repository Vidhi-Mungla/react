import React from 'react'

function Hotel() {
  return (
    <div>
        <h1 className='text-center'>this is Hotel Page</h1>
    </div>
  )
}

export default Hotel