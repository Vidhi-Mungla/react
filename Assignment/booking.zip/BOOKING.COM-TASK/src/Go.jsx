import React from 'react'

function Go() {
  return (
    <div>
        <h1>
            This is second page
        </h1>
    </div>
  )
}

export default Go