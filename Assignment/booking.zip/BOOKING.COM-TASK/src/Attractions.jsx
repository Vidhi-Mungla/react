import React from 'react'

function Attractions() {
  return (
    <div>
        <h1 style={{textAlign:"center"}}>
        Attractions Page Comming Soon
        </h1>
    </div>
  )
}

export default Attractions