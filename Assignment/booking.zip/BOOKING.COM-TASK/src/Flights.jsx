import React from 'react'

function Flights() {
  return (
    <div>
         <h1 style={{textAlign:"center"}}>
        Flights Page Comming Soon
        </h1>
    </div>
  )
}

export default Flights