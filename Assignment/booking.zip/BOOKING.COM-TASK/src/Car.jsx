import React from 'react'

function Car() {
  return (
    <div>
        <h1 style={{textAlign:"center"}}>
        Car Rentals Page Comming Soon
        </h1>
    </div>
  )
}

export default Car